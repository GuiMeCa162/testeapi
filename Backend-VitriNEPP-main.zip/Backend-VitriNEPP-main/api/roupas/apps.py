from django.apps import AppConfig


class RoupasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'roupas'
